<?php

/**
 * @author khalifalmahmud
 * @package kportfolio
 */

namespace KHALIF\kportfolio\INCLUDES;

use KHALIF\kportfolio\INCLUDES\Admin\Admin;
use KHALIF\kportfolio\INCLUDES\CptCt\CptCt;
use KHALIF\kportfolio\INCLUDES\Front\Front;

class Includes
{
    /**
     * Class construcotr
     */
    public function __construct()
    {
        $this->admin_public();

        new CptCt;
        add_action('add_meta_boxes', [$this, 'usage_add_meta_box']);
        add_action('add_meta_boxes', [$this, '_portfolio_url_add_meta_box']);
        add_action('save_post', [$this, '_portfolio_url_save']);
        add_shortcode('P_O_R_T_F_O_L_I_O', [$this, 'portfolio_shortcode']);
    }

    /**
     * Function admin_public
     */
    public function admin_public()
    {
        if (is_admin()) {
            new Admin;
        } else {
            new Front;
        }
    }

    /** Shotcode uage*/
    function usage_add_meta_box()
    {
        add_meta_box(
            'usage-usage',
            __('USAGE', 'usage'),
            function () {
?>
            <p>Use <span class="shortcodeportfolio">[P_O_R_T_F_O_L_I_O]</span> For Showing All Portfolio</p>
        <?php
            },
            'kportfolio',
            'side',
            'high'
        );
    }

    /**Portfolio */
    function _portfolio_url_add_meta_box()
    {
        add_meta_box(
            '_portfolio_url-portfolio-url',
            __(' Portfolio Url', '_portfolio_url'),
            [$this, '_portfolio_url_html'],
            'kportfolio',
            'normal',
            'high'
        );
    }

    function _portfolio_url_html($post)
    {
        wp_nonce_field('__portfolio_url_nonce', '_portfolio_url_nonce');
        ?>
        <p>Here You Can Add Your Portfolio Url</p>
        <p>
            <label for="_portfolio_url_enter_portfolio_url"><?php _e('Enter Portfolio Url', '_portfolio_url'); ?></label><br>
            <input type="url" name="_portfolio_url_enter_portfolio_url" id="_portfolio_url_enter_portfolio_url" value="<?php echo get_post_meta($post->ID, '_portfolio_url_enter_portfolio_url', true); ?>">
        </p><?php
        }

        function _portfolio_url_save($post_id)
        {
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
                return;
            }
            if (!isset($_POST['_portfolio_url_nonce']) || !wp_verify_nonce($_POST['_portfolio_url_nonce'], '__portfolio_url_nonce')) {
                return;
            }
            if (!current_user_can('edit_post', $post_id)) {
                return;
            }
            if (isset($_POST['_portfolio_url_enter_portfolio_url'])) {
                update_post_meta($post_id, '_portfolio_url_enter_portfolio_url', esc_attr($_POST['_portfolio_url_enter_portfolio_url']));
            }
        }

        /**Main Shortcode */
        function portfolio_shortcode()
        {
            ob_start();
            ?>
        <div class="row">
            <?php
            $posts = get_posts([
                'posts_per_page' => -1,
                'post_type'      => 'kportfolio',
                'posts_per_page' => 3,
            ]);
            if ($posts) {
                foreach ($posts as $post) {
                    setup_postdata($post);
                    $portfolioUrl  = get_the_post_thumbnail_url($post->ID);
                    $title         = $post->post_title;
                    $portfolio_url = get_post_meta($post->ID, '_portfolio_url_enter_portfolio_url', true);
            ?>
                    <div class="card col-md-3 mb-1 mt-1">
                        <a href="<?php echo $portfolio_url; ?>">
                            <img class="card-img-top portfolioimage" src="<?php echo $portfolioUrl; ?>">
                        </a>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $title; ?></h5>
                        </div>
                    </div>
            <?php
                }
                wp_reset_postdata();
            }
            ?>
        </div>
        <br />
        <br />
        <div class="portfolioloadmore">
            <a href="#">Load More Portfolio</a>
        </div>
<?php
            return ob_get_clean();
        }
    }
