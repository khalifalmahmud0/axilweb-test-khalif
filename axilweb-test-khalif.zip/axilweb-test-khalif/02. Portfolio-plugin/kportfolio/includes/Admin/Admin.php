<?php

/**
 * @author khalifalmahmud
 * @package kportfolio
 */

namespace KHALIF\kportfolio\INCLUDES\Admin;

use KHALIF\kportfolio\INCLUDES\Admin\Assets\Assets;

class Admin
{
    /**
     * Class construcotr
     */
    public function __construct()
    {
        new Assets;
    }
}
