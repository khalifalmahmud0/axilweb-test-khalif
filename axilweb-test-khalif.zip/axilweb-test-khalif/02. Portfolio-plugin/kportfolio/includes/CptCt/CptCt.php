<?php

/**
 * @author khalifalmahmud
 * @package kportfolio
 */

namespace KHALIF\kportfolio\INCLUDES\CptCt;

use KHALIF\kportfolio\INCLUDES\CptCt\Cpt\Cpt;

class CptCt
{
    /**
     * Class constructor.
     */
    public function __construct()
    {
        new Cpt;
    }
}
