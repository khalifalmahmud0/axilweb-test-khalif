<?php

/**
 * @author khalifalmahmud
 * @package kportfolio
 */

namespace KHALIF\kportfolio\INCLUDES\CptCt\Cpt;

use KHALIF\kportfolio\INCLUDES\CptCt\Cpt\Files\Portfolio_Cpt;

class Cpt
{
    /**
     * Class constructor.
     */
    public function __construct()
    {
        new Portfolio_Cpt;
    }
}
