<?php

namespace KHALIF\kportfolio\INCLUDES\CptCt\Cpt\Files;

class Portfolio_Cpt
{
    public function __construct()
    {
        add_action('init', [$this, 'cptui_register_my_cpts_kportfolio']);
    }

    /**
     * Post Type: Portfolios.
     */

    function cptui_register_my_cpts_kportfolio()
    {

        $labels = [
            'name'                     => __('Portfolios', 'akhalif'),
            'singular_name'            => __('Portfolio', 'akhalif'),
            'menu_name'                => __('Portfolios', 'akhalif'),
            'all_items'                => __('All Portfolios', 'akhalif'),
            'add_new'                  => __('Add New Portfolio', 'akhalif'),
            'add_new_item'             => __('Add New Portfolio Item', 'akhalif'),
            'edit_item'                => __('Edit Portfolio', 'akhalif'),
            'new_item'                 => __('New Portfolio', 'akhalif'),
            'view_item'                => __('View Portfolio', 'akhalif'),
            'view_items'               => __('View Portfolios', 'akhalif'),
            'search_items'             => __('Search Portfolio', 'akhalif'),
            'not_found'                => __('No Portfolio Found', 'akhalif'),
            'not_found_in_trash'       => __('No Portfolio Item Found In Trush', 'akhalif'),
            'featured_image'           => __('Portfolio Image', 'akhalif'),
            'set_featured_image'       => __('Set Portfolio Image', 'akhalif'),
            'remove_featured_image'    => __('Remove Portfolio Image', 'akhalif'),
            'use_featured_image'       => __('Use Portfolio Image', 'akhalif'),
            'archives'                 => __('Portfolio Archives', 'akhalif'),
            'insert_into_item'         => __('Insert Into Portfolio', 'akhalif'),
            'uploaded_to_this_item'    => __('Uploaded to this Portfolio', 'akhalif'),
            'filter_items_list'        => __('Filter Portfolio Items List', 'akhalif'),
            'items_list_navigation'    => __('Portfolio List Navigation', 'akhalif'),
            'items_list'               => __('Portfolio List', 'akhalif'),
            'attributes'               => __('Portfolio Attributes', 'akhalif'),
            'name_admin_bar'           => __('Portfolio', 'akhalif'),
            'item_published'           => __('Portfolio Published', 'akhalif'),
            'item_published_privately' => __('Portfolio Published Privately', 'akhalif'),
            'item_reverted_to_draft'   => __('Portfolio Item Reverted To Draft', 'akhalif'),
            'item_scheduled'           => __('Portfolio Item Scheduled', 'akhalif'),
            'item_updated'             => __('Portfolio Item Updated', 'akhalif'),
        ];

        $args = [
            'label'                 => __('Portfolios', 'akhalif'),
            'labels'                => $labels,
            'description'           => 'This Is a Portfolio Manager Post Type',
            'public'                => true,
            'publicly_queryable'    => true,
            'show_ui'               => true,
            'show_in_rest'          => true,
            'rest_base'             => '',
            'rest_controller_class' => 'WP_REST_Posts_Controller',
            'has_archive'           => false,
            'show_in_menu'          => true,
            'show_in_nav_menus'     => true,
            'delete_with_user'      => false,
            'exclude_from_search'   => false,
            'capability_type'       => 'post',
            'map_meta_cap'          => true,
            'hierarchical'          => false,
            'rewrite'               => ['slug' => 'kportfolio', 'with_front' => true],
            'query_var'             => true,
            'menu_icon'             => 'dashicons-portfolio',
            'supports'              => ['title', 'thumbnail'],
        ];

        register_post_type('kportfolio', $args);
    }
}
