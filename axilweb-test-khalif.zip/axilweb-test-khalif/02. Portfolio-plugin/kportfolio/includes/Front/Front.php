<?php

/**
 * @author khalifalmahmud
 * @package kportfolio
 */

namespace KHALIF\kportfolio\INCLUDES\Front;

use KHALIF\kportfolio\INCLUDES\Front\Assets\Assets;

class Front
{
    /**
     * Class construcotr
     */
    public function __construct()
    {
        new Assets;
    }
}
