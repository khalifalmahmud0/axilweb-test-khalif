<?php

/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package akhalif
 */
get_header();
?>
<div class="container">
    <div class="row mt-30">
        <div class="col-md-8 pl-5 pr-5 contentArea">
            <div class="row">
                <h1 class="page-title"><?php esc_html_e('Oops! That page can&rsquo;t be found.', 'akhalif'); ?></h1>
            </div>
        </div>
    </div>
</div>
<?php
get_footer();
