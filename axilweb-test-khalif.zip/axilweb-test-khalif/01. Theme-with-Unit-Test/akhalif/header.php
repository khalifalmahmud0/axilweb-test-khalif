<?php

/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package akhalif
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        .custom-logo {
            width: 25%;
        }

        .site-branding {
            text-align: center;
        }

        .site-title {
            padding: 0px;
            margin: 0px;
        }

        #navbarNavDropdown {
            margin-left: 25%;
        }

        .card-header.widgrt {
            margin-bottom: 10px;
        }

        .SidebarArea ul {
            list-style: none;
        }

        .SidebarArea ul {
            list-style: none;
            margin: 0px;
            padding: 0px 20px;
        }

        .card.mb-3.col-md-12.singlewidget {
            padding-bottom: 20px;
        }

        .singlewidget .attachment-thumbnail.size-thumbnail {
            height: 50px !important;
        }

        .singlewidget .gallery-item {
            margin: 0px;
            padding: 0px;
        }

        .container.bg-light.copyright {
            padding: 20px;
        }

        .bg-light {
            background-color: gainsboro !important;
        }

        .container.full {
            border: 1px solid gainsboro;
        }
    </style>
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <div class="container full">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="site-branding">
                    <?php
                    the_custom_logo();
                    if (is_front_page() && is_home()) :
                    ?>
                        <h1 class="site-title"><a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name'); ?></a></h1>
                    <?php
                    else :
                    ?>
                        <p class="site-title"><a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name'); ?></a></p>
                    <?php
                    endif;
                    $akhalif_description = get_bloginfo('description', 'display');
                    if ($akhalif_description || is_customize_preview()) :
                    ?>
                        <p class="site-description"><?php echo $akhalif_description; ?></p>
                    <?php endif; ?>
                </div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <?php
                    wp_nav_menu([
                        'theme_location' => 'menu-1',
                        'menu_class'     => 'nav navbar-nav navbar-right',
                        'menu_id'        => 'nav',
                        'walker'         => new akhalif_waker(),
                    ]);
                    ?>
                </div>
            </nav>
        </div>
        <br />
        <br />