<?php

/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package akhalif
 */
get_header();
?>
<style>
    .card-title {
        font-size: 30px !important;
        font-weight: bold !important;
    }
</style>
<div class="container">
    <div class="row mt-30">
        <div class="col-md-12 pl-5 pr-5 contentArea">
            <div class="row">
                <?php if (have_posts()) {
                    while (have_posts()) {
                        the_post();
                ?>
                        <div class="card col-md-12 mb-1 mt-1">
                            <?php
                            if (has_post_thumbnail()) {
                            ?>
                                <img class="card-img-top" src="<?php the_post_thumbnail_url(); ?>" alt="Card image cap">
                            <?php
                            }
                            ?>
                            <div class="card-body">
                                <h5 class="card-title text-center"><?php the_title(); ?></h5>
                                <p class="card-text">
                                    <?php the_content(); ?>
                                </p>
                            </div>
                            <?php
                            the_post_navigation(
                                [
                                    'prev_text' => '<span class="nav-subtitle">' . esc_html__('Previous:', 'akhalif') . '</span> <span class="nav-title">%title</span>',
                                    'next_text' => '<span class="nav-subtitle">' . esc_html__('Next:', 'akhalif') . '</span> <span class="nav-title">%title</span>',
                                ]
                            );

                            // If comments are open or we have at least one comment, load up the comment template.
                            if (comments_open() || get_comments_number()) :
                                comments_template();
                            endif;
                            ?>
                        </div>
                <?php
                    }
                } ?>

            </div>
        </div>

    </div>
</div>
<?php
get_footer();
?>