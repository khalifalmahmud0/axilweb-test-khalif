<?php

/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package akhalif
 */
get_header();
if (!is_active_sidebar('sidebar-1')) {
    $class = 'col-md-12';
} else {
    $class = 'col-md-8';
}
?>
<div class="container">
    <div class="row mt-30">
        <div class="pl-5 pr-5 contentArea                                         		                                 		                                  <?php echo $class; ?>">
            <div class="row">
                <?php if (have_posts()) {
                    while (have_posts()) {
                        the_post();
                ?>
                        <div class="card col-md-4 mb-1 mt-1">
                            <?php
                            if (has_post_thumbnail()) {
                            ?>
                                <img class="card-img-top" src="<?php the_post_thumbnail_url(); ?>" alt="Card image cap">
                            <?php
                            }
                            ?>
                            <div class="card-body">
                                <h5 class="card-title text-center"><?php the_title(); ?></h5>
                                <p class="card-text">
                                    <?php
                                    $readmore = __('Read More', 'akhalif');
                                    $more     = '   <a href="' . get_permalink() . '">' . $readmore . '</a>';
                                    echo wp_trim_words(get_the_content(), 10, $more);
                                    ?>
                                </p>
                            </div>
                        </div>
                <?php
                    }
                } ?>
            </div>
        </div>
        <div class="col-md-4 pl-5 pr-5 SidebarArea">
            <?php get_sidebar(); ?>
        </div>
    </div>
</div>
<?php
get_footer();
?>