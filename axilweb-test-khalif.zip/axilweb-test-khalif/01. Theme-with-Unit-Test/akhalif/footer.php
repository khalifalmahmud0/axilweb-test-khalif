<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package akhalif
 */
?>
<br />
<br />
<div class="container bg-light copyright">
    <div class="row">
        <div class="col-md-12 d-flex justify-content-center">
            <a href="<?php echo esc_url(__('https://wordpress.org/', 'akhalif')); ?>">
                <?php
                /* translators: %s: CMS name, i.e. WordPress. */
                printf(esc_html__('Proudly powered by %s', 'akhalif'), 'WordPress');
                ?>
            </a>
        </div>
    </div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<?php wp_footer(); ?>
</body>

</html>